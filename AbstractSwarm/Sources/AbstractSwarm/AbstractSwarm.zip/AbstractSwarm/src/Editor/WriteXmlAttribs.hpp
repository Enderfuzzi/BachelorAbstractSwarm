/*
AbstractSwarm - Graphical multi-agent modeling/simulation environment
Copyright (C) 2019  Daan Apeldoorn (daan.apeldoorn@uni-mainz.de)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#if !defined WriteXmlAttribs_hmol
	#define WriteXmlAttribs_hmol





//#include "WriteXmlEditorObjAttribs.hmol"
#include "WriteXmlEditorObjAttribs.hpp"
#include <iosfwd>





using namespace std;





class CEditor;





//method MWriteXmlAttribs( ofstream& ofsOutputFile ) : MWriteXmlEditorObjAttribs( ofstream& ofsOutputFile )
class MWriteXmlAttribs : public MWriteXmlEditorObjAttribs
{
#define METHOD_PARAMS_WRITEXMLATTRIBS ofstream& ofsOutputFile

public:

	//
	// Handlings
	//

//	void <CEditor*>();
    static void handling( CEditor* that, METHOD_PARAMS_WRITEXMLATTRIBS );

	// Handling for component type attributes (Priority, Frequency, etc.) 	
//	void <int>();
    static void handling( int that, METHOD_PARAMS_WRITEXMLATTRIBS );


    // C-MOL DISPATCHER HANDLING FOR RUNTIME POLYMORPHISM
    // (DO NOT FORGET TO ADD/CHANGE IF-STATEMENTS HERE WHEN ADDING/CHANGING POLYMORPHIC HANDLINGS!)
    static inline void handling( void* vp_that, METHOD_PARAMS_WRITEXMLATTRIBS )
    {
        if( typeid( *(static_cast<CPerspective*>( vp_that ))) == typeid( CPerspective ) )
            handling( static_cast<CPerspective*>( vp_that ), ofsOutputFile );
        else if( typeid( *(static_cast<CAgentType*>( vp_that ))) == typeid( CAgentType ) )
            handling( static_cast<CAgentType*>( vp_that ), ofsOutputFile );
        else if( typeid( *(static_cast<CStationType*>( vp_that ))) == typeid( CStationType ) )
            handling( static_cast<CStationType*>( vp_that ), ofsOutputFile );
        else if( typeid( *(static_cast<CVisitEdge*>( vp_that ))) == typeid( CVisitEdge ) )
            handling( static_cast<CVisitEdge*>( vp_that ), ofsOutputFile );
        else if( typeid( *(static_cast<CPlaceEdge*>( vp_that ))) == typeid( CPlaceEdge ) )
            handling( static_cast<CPlaceEdge*>( vp_that ), ofsOutputFile );
        else if( typeid( *(static_cast<CTimeEdge*>( vp_that ))) == typeid( CTimeEdge ) )
            handling( static_cast<CTimeEdge*>( vp_that ), ofsOutputFile );
        else
            throw( "C-mol runtime error: no polymorphic handling for that type" );
    }


    //
    // C-MOL INHERITANCE MECHANISM
    // (DO NOT FORGET TO OVERWRITE ALL INHERITED HANDLINGS HERE FOR SUPER-PROLOGUE/-EPILOGUE CALLS!)
    //

    static inline void handling( CPerspective* that, METHOD_PARAMS_WRITEXMLATTRIBS )
    {
//        prologue( that, ofsOutputFile );
        MWriteXmlEditorObjAttribs::handling( that, ofsOutputFile );
//        epilogue( that, ofsOutputFile );
    }

    static inline void handling( CStationType* that, METHOD_PARAMS_WRITEXMLATTRIBS )
    {
//        prologue( that, ofsOutputFile );
        MWriteXmlEditorObjAttribs::handling( that, ofsOutputFile );
//        epilogue( that, ofsOutputFile );
    }

    static inline void handling( CAgentType* that, METHOD_PARAMS_WRITEXMLATTRIBS )
    {
//        prologue( that, ofsOutputFile );
        MWriteXmlEditorObjAttribs::handling( that, ofsOutputFile );
//        epilogue( that, ofsOutputFile );
    }

    static inline void handling( CVisitEdge* that, METHOD_PARAMS_WRITEXMLATTRIBS )
    {
//        prologue( that, ofsOutputFile );
        MWriteXmlEditorObjAttribs::handling( that, ofsOutputFile );
//        epilogue( that, ofsOutputFile );
    }

    static inline void handling( CPlaceEdge* that, METHOD_PARAMS_WRITEXMLATTRIBS )
    {
//        prologue( that, ofsOutputFile );
        MWriteXmlEditorObjAttribs::handling( that, ofsOutputFile );
//        epilogue( that, ofsOutputFile );
    }

    static inline void handling( CTimeEdge* that, METHOD_PARAMS_WRITEXMLATTRIBS )
    {
//        prologue( that, ofsOutputFile );
        MWriteXmlEditorObjAttribs::handling( that, ofsOutputFile );
//        epilogue( that, ofsOutputFile );
    }
};





#endif
