#include "../../src/svg/qsvgwidget.h"
