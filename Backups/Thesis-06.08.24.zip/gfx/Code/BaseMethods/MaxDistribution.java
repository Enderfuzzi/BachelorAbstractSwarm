private static double maxDistribution(Agent me, HashMap<Agent, Object> others, Station station) {		
    double result = 0.0;
    for (Object object : others.values()) {
        if (object == null) continue;
        Object[] communication = (Object[]) object;
        if (((Station) communication[0]) == station) {
            result -= 2.0;
        }
    }
    return result + 2.0 * stationSpace(me, others, station);
}

/**
* Extracts the initial space of a station type. Returns 1 if the station type has no space attribute.
* @param station The station type to check.
* @return The space of a station or 1 if the station has no space attribute
*/
private static int stationSpace(StationType station) {
	if (station.space == -1) return 1;
	return station.space;
}