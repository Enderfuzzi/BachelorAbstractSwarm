
/**
* This method allows an agent to perceive its current state and to perform
 * actions by returning an evaluation value for potential next target
 * stations. The method is called for every station that can be visted by
 * the agent. 
 * 
 * @param me        the agent itself
 * @param others    all other agents in the scenario with their currently
 *                  communicated information
 * @param stations  all stations in the scenario
 * @param time      the current time unit
 * @param station   the station to be evaluated as potential next target
 * 
 * @return          the evaluation value of the station
 */
public static double evaluation(Agent me, HashMap<Agent, Object> others, 
	List<Station> stations, long time, Station station ) {

}

/**
 * This method allows an agent to communicate with other agents by
 * returning a communication data object.
 * 
 * @param me           the agent itself
 * @param others       all other agents in the scenario with their
 *                     currently communicated information
 * @param stations     all stations in the scenario
 * @param time         the current time unit
 * @param defaultData  a triple (selected station, time unit when the 
 *                     station is reached, evaluation value of the station)
 *                     that can be used for default communication
 * 
 * @return             the communication data object
 */
public static Object communication(Agent me, HashMap<Agent, Object> others, 
	List<Station> stations, long time, Object[] defaultData ) {

}

/**
 * This method allows an agent to perceive the local reward for its most
 * recent action.
 * 
 * @param me           the agent itself
 * @param others       all other agents in the scenario with their
 *                     currently communicated information
 * @param stations     all stations in the scenario
 * @param time         the current time unit
 * @param value        the local reward in [0, 1] for the agent's most
 *                     recent action 
 */
public static void reward(Agent me, HashMap<Agent, Object> others, 
	List<Station> stations, long time, double value ) {

}
