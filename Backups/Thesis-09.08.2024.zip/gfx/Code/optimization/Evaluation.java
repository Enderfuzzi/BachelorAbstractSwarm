public static double evaluate(Agent me, HashMap<Agent, Object> others, List<Station> stations, long time, Station station, TimeStatistics timeStatistic) {
    if (firstRun) {

        directedTimeEdges = graphHasDirectedTimeEdges(stations);
        undirectedTimeEdges = graphHasUndirectedTimeEdges(stations);
        stationFrequency = graphHasStationFrequency(stations);
        agentFrequency = graphHasAgentFrequency(me, others);
        
        attributeNodes.put(Attribute.STATION_FREQUENCY, new Node((OwnConsumer) Calculations::stationFrequency));
        
        
        attributeNodes.put(Attribute.AGENT_FREQUENCY, new Node((OwnConsumer) Calculations::computeAgentFrequency));
        
        attributeNodes.put(Attribute.MAX_DISTRIBUTION, new Node((OwnConsumer) Calculations::maxDistribution));
        
        if (directedTimeEdges) {
            attributeNodes.put(Attribute.INCOMING_TIME_CONNECTION, new Node((OwnConsumer) Calculations::computeIncomingConnectedStations));
            attributeNodes.put(Attribute.OUTGOING_TIME_CONNECTION, new Node((OwnConsumer) Calculations::computeOutgoingConnectedStations));
        }
        if (undirectedTimeEdges) {
            attributeNodes.put(Attribute.UNDIRECTED_TIME_CONNECTION, new Node((OwnConsumer) Calculations::computeUndirectedTimeConnectedStations));
        }
        attributeNodes.put(Attribute.PATH_COST, new Node(Operator.MULTIPLICATION, -1.0, new Node((OwnConsumer) Calculations::pathCost)));
        attributeNodes.put(Attribute.STATION_SPACE, new Node(Operator.DIVISION, new Node((OwnConsumer) Calculations::stationSpace), new Node((OwnConsumer) Calculations::agentSize)));
        attributeNodes.put(Attribute.AGENT_TIME, new Node(Operator.DIVISION, new Node((OwnConsumer) Calculations::totalAgentTime), new Node((OwnConsumer) Calculations::estimatedWorkTimeLeft)));
        
    
        
        if (directedTimeEdges) {
            statistic.add("directedTime");
        }
        
        if (undirectedTimeEdges) {
            statistic.add("undirectedTime");
        }
        
    }
    
    
    if (!totalTime.containsKey(me.type)) {
        totalTime.put(me.type, estimatedWorkTimeLeft(me, others, station));
    }
    
    // Regardless of plans if the station would result in a deadlock don't choose it
    if (!otherStationsReachable(me, station)) {
        return -100;
    }
    // agent to large
    if (agentSize(me, others, station) > stationSpace(me, others, station)) {
        return -100;
    }
    //station is not reachable
    if (pathCost(me.previousTarget.type, station.type) == -1) {
        return -100;
    }
    
    
    if (timeStatistic.newRun) {
        if (TEXT_OUTPUT) System.out.println(statistic);
        
        statistic.newRandom();
        if (timeStatistic.newBestRun || (timeStatistic.lastRunCompleted && timeStatistic.currentTwT <= Math.round(timeStatistic.lowestTwT * 1.6))) {
            statistic.reset();
        } else {
            if (timeStatistic.lastRunCompleted) statistic.recover();
        }
        
        decision.clear();
        
        if (TEXT_OUTPUT) System.out.println(statistic.getAverage());
    }
    
    Node currentNode = new Node(0);
    
    if (statistic.compare("path")) {
        currentNode.addNode(attributeNodes.get(Attribute.PATH_COST));
    }
    
    if (statistic.compare("space")) {
        currentNode.addNode(attributeNodes.get(Attribute.STATION_SPACE));
    }
    
    if (statistic.compare("distribution")) {

        if (stationFrequency) {
            currentNode.addNode(attributeNodes.get(Attribute.STATION_FREQUENCY));
        }
        if (agentFrequency) {
            currentNode.addNode(attributeNodes.get(Attribute.AGENT_FREQUENCY));
            
        }
    }
    
    if (statistic.compare("directedTime")) {
        currentNode.addNode(attributeNodes.get(Attribute.INCOMING_TIME_CONNECTION));
        currentNode.addNode(attributeNodes.get(Attribute.OUTGOING_TIME_CONNECTION));
    }
    
    if (statistic.compare("undirectedTime")) {
        currentNode.addNode(attributeNodes.get(Attribute.UNDIRECTED_TIME_CONNECTION));
    }
    
    

    if ((!stationFrequency && !agentFrequency || !statistic.compare("distribution")) 
            && !statistic.compare("space") && !statistic.compare("path") && !statistic.compare("directedTime") && !statistic.compare("undirectedTime")) {
        currentNode.addNode(attributeNodes.get(Attribute.MAX_DISTRIBUTION));
    }
    
    firstRun = false;
    
    if (!decision.containsKey(me)) {
        decision.put(me, statistic.getCurrentComparison());
    }
    
    return currentNode.evaluate(me, others, station);
}