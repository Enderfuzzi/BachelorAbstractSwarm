private static List<Tree> currentTrees = new ArrayList<>();
private static int currentTreeIndex = 0;
private static List<Tree> bestTrees = new ArrayList<>();

private static boolean generateTree = true;

private static List<Tree> crossoverTree = new ArrayList<>();


private static List<FitnessPair> treeFitness = new ArrayList<>();


public static double evaluate(Agent me, HashMap<Agent, Object> others, List<Station> stations, long time, Station station, TimeStatistics timeStatistic) {
    double currentFitness = 0.0;
		
    if (timeStatistic.newRun && timeStatistic.lastRunCompleted) {
        if (timeStatistic.newBestRun) {
            
            for (FitnessPair pair : treeFitness) {
                pair.fitness *= 0.9;
            }
        }
        
        if (timeStatistic.currentTwT == 0L) {
            currentFitness = 1.0;
        } else {
            currentFitness = timeStatistic.lowestTwT / timeStatistic.currentTwT;
        }
        
        if (currentFitness > 0.0) {
            treeFitness.add(new FitnessPair(currentFitness, currentTrees));
            
            if (treeFitness.size() > 20) {
                
                FitnessPair toRemove = null;
                for (FitnessPair pair : treeFitness) {
                    if (toRemove == null || toRemove.fitness > pair.fitness) {
                        toRemove = pair;
                    }
                }
                
                if (toRemove != null) treeFitness.remove(toRemove);
            }
        }
    }

    if (timeStatistic.newRun && !generateTree) {
        mutationProbability.newRandom();
        if (mutationProbability.compare("largeCrossover") && !treeFitness.isEmpty()) {
            deactivateMutation = true;
            
            crossoverTree = TreeMutation.largeCrossover(currentTrees, treeFitness.get(random.nextInt(treeFitness.size())).trees);
            
        } else {
            deactivateMutation = false;
        }
    }

    Tree evaluation = new Tree();
		
    if (timeStatistic.lastValue != timeStatistic.time) {
        currentTreeIndex++;	
        
        if (generateTree || currentTreeIndex >= bestTrees.size() || (!deactivateMutation && currentTreeIndex >= crossoverTree.size())) {
        
            if (timeStatistic.newRun) {
                if (TEXT_OUTPUT) System.out.println(baseProbability);
                
                baseProbability.newRandom();
                if (timeStatistic.newBestRun || (timeStatistic.lastRunCompleted && timeStatistic.currentTwT <= Math.round(timeStatistic.lowestTwT * 1.6))) {
                    baseProbability.reset();
                } else {
                    //if (timeStatistic.lastRunCompleted) baseProbability.recover();
                    baseProbability.recover();
                }
                
                decision.clear();
                
                if (TEXT_OUTPUT) System.out.println(baseProbability.getAverage());
            }
            
            
            
            
            if (baseProbability.compare("path")) {
                evaluation.addNode(attributeNodes.get(Attribute.PATH_COST));
            }
            
            if (baseProbability.compare("space")) {
                evaluation.addNode(attributeNodes.get(Attribute.STATION_SPACE));
            }
            
            if (baseProbability.compare("distribution")) {
    
                if (stationFrequency) {
                    evaluation.addNode(attributeNodes.get(Attribute.STATION_FREQUENCY));
                    
                }
                if (agentFrequency) {
                    evaluation.addNode(attributeNodes.get(Attribute.AGENT_FREQUENCY));
                    
                }
            }
            
            if (baseProbability.compare("directedTime")) {
                evaluation.addNode(attributeNodes.get(Attribute.INCOMING_TIME_CONNECTION));
                evaluation.addNode(attributeNodes.get(Attribute.OUTGOING_TIME_CONNECTION));
            }
            
            if (baseProbability.compare("undirectedTime")) {
                evaluation.addNode(attributeNodes.get(Attribute.UNDIRECTED_TIME_CONNECTION));
            }
            
            
            if ((!stationFrequency && !agentFrequency || !baseProbability.compare("distribution")) && !baseProbability.compare("space") && !baseProbability.compare("path") && 
                    !baseProbability.compare("directedTime") && !baseProbability.compare("undirectedTime")) {
                evaluation.addNode(attributeNodes.get(Attribute.MAX_DISTRIBUTION));
            }
            
            if (!decision.containsKey(me)) {
                decision.put(me, baseProbability.getCurrentComparison());
            }
            
        } else {
            
            if (!deactivateMutation) {
                evaluation = bestTrees.get(currentTreeIndex).copy();

                if (timeStatistic.newRun) {
                    mutationProbability.newRandom();
                    basicMutationProbability.newRandom();
                }
                
                if (timeStatistic.lastValue != timeStatistic.time || currentTrees.size() < 1) {
                    if (mutationProbability.compare("mutation")) {
                        
                        if (basicMutationProbability.compare("value")) {
                            evaluation = TreeMutation.valueMutation(evaluation);
                        } else {
                            evaluation = TreeMutation.mutateOperator(mutationStatistic, evaluation);
                        }                          
                    }
                    
                    if (!mutationProbability.compare("mutation") && mutationProbability.compare("crossover") && !treeFitness.isEmpty()) {
                        
                        List<Tree> crossover = treeFitness.get(random.nextInt(treeFitness.size())).trees;
                        
                        if (crossover.size() > currentTreeIndex) {
                            evaluation = TreeMutation.crossover(evaluation, crossover.get(currentTreeIndex));
                        } else {
                            evaluation = TreeMutation.crossover(evaluation, crossover.get(crossover.size() - 1));
                        }
                    }
                    
                    
                    
                } else {
                    evaluation = currentTrees.get(currentTrees.size() - 1);
                }
            } else {
                if (crossoverTree.size() > currentTreeIndex) {
                    evaluation = crossoverTree.get(currentTreeIndex).copy();
                }
            }
            
        }
        
        
        currentTrees.add(evaluation);
    }
    if (currentTrees.size() > 0) {
        evaluation = currentTrees.get(currentTrees.size() - 1);
    } 
    
    if (timeStatistic.numberOfRuns >= 30) {
        generateTree = false;
    }
    
    firstRun = false;
    
    return evaluation.evaluate(me, others, station);
}