private static double maxDistribution(Agent me, HashMap<Agent, Object> others, Station station) {		
    return -2.0 * stationTargeted(me, others, station) + 2.0 * stationSpace(me, others, station);
}

/**
* Extracts the initial space of a station type. Returns 1 if the station type has no space attribute.
* @param station The station type to check.
* @return The space of a station or 1 if the station has no space attribute
*/
private static int stationSpace(StationType station) {
	if (station.space == -1) return 1;
	return station.space;
}

private static int stationTargeted(Agent me, HashMap<Agent, Object> others, Station station) {
    int counter = 0;
    for (Object object : others.values()) {
        if (object == null) continue;
        Object[] communication = (Object[]) object;
        if (((Station) communication[0]) == station) {
            counter += 1;
        }
    }
    if (TEXT_OUTPUT) System.out.println("Station target: " + station.name + " Number: " + counter);
    return counter;
}