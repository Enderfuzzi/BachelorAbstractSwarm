class FitnessPair {
	
	double fitness;
	
	List<Tree> trees;
	
	public FitnessPair(double fitness, List<Tree> trees) {
		this.fitness = fitness;
		this.trees = new ArrayList<>(trees);
	}
	
	public String toString() {
		return String.format("[Fitness=%f,Trees=%s]", fitness, trees.toString());
	}
	
}