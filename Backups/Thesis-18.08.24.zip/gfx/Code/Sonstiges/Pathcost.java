record Pair(StationType station, Integer cost) implements Comparable<Pair> {
    @Override
    public int compareTo(Pair other) {
        return Integer.compare(this.cost, other.cost);
    }	
};

private static int pathCost(StationType start, StationType target) {
    PriorityQueue<Pair> queue = new PriorityQueue<>();
    List<StationType> used = new ArrayList<>();
    queue.add(new Pair(start, 0));
    while (!queue.isEmpty()) {
        Pair current = queue.poll();
        if (used.contains(current.station())) continue;
        used.add(current.station());
        if (current.station() == target) {
            return current.cost();
        }
        
        for (PlaceEdge edge : current.station().placeEdges) {
            if (edge.incoming) continue;
            queue.add(new Pair((StationType) edge.connectedType, current.cost() + edge.weight));
        }
        
    }
    return -1;
}