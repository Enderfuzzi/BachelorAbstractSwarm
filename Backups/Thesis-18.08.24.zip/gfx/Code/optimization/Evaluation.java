private static HashMap<Agent, List<String>> decision = new HashMap<>();

public static double evaluate(Agent me, HashMap<Agent, Object> others, List<Station> stations, long time, Station station, TimeStatistics timeStatistic) {
    if (firstRun) {

        directedTimeEdges = graphHasDirectedTimeEdges(stations);
        undirectedTimeEdges = graphHasUndirectedTimeEdges(stations);
        stationFrequency = graphHasStationFrequency(stations);
        agentFrequency = graphHasAgentFrequency(me, others);
        
        attributeNodes.put(Attribute.STATION_FREQUENCY, new Node((OwnConsumer) Calculations::stationFrequency));
        
        
        attributeNodes.put(Attribute.AGENT_FREQUENCY, new Node((OwnConsumer) Calculations::computeAgentFrequency));
        
        attributeNodes.put(Attribute.MAX_DISTRIBUTION, new Node((OwnConsumer) Calculations::maxDistribution));
        
        if (directedTimeEdges) {
            attributeNodes.put(Attribute.INCOMING_TIME_CONNECTION, new Node((OwnConsumer) Calculations::computeIncomingConnectedStations));
            attributeNodes.put(Attribute.OUTGOING_TIME_CONNECTION, new Node((OwnConsumer) Calculations::computeOutgoingConnectedStations));
        }
        if (undirectedTimeEdges) {
            attributeNodes.put(Attribute.UNDIRECTED_TIME_CONNECTION, new Node((OwnConsumer) Calculations::computeUndirectedTimeConnectedStations));
        }
        attributeNodes.put(Attribute.PATH_COST, new Node(Operator.MULTIPLICATION, -1.0, new Node((OwnConsumer) Calculations::pathCost)));
        attributeNodes.put(Attribute.STATION_SPACE, new Node(Operator.DIVISION, new Node((OwnConsumer) Calculations::stationSpace), new Node((OwnConsumer) Calculations::agentSize)));
        attributeNodes.put(Attribute.AGENT_TIME, new Node(Operator.DIVISION, new Node((OwnConsumer) Calculations::totalAgentTime), new Node((OwnConsumer) Calculations::estimatedWorkTimeLeft)));
        
    
        
        if (directedTimeEdges) {
            probabilityStatistic.add("directedTime");
        }
        
        if (undirectedTimeEdges) {
            probabilityStatistic.add("undirectedTime");
        }
        
    }
    
    
    if (!totalTime.containsKey(me.type)) {
        totalTime.put(me.type, estimatedWorkTimeLeft(me, others, station));
    }
    
    // Regardless of plans if the station would result in a deadlock don't choose it
    if (!otherStationsReachable(me, station)) {
        return -100;
    }
    // agent to large
    if (agentSize(me, others, station) > stationSpace(me, others, station)) {
        return -100;
    }
    //station is not reachable
    if (pathCost(me.previousTarget.type, station.type) == -1) {
        return -100;
    }
    
    
    if (timeStatistic.newRun) {
        if (TEXT_OUTPUT) System.out.println(probabilityStatistic);
        
        probabilityStatistic.newRandom();
        if (timeStatistic.newBestRun || (timeStatistic.lastRunCompleted && timeStatistic.currentTwT <= Math.round(timeStatistic.lowestTwT * 1.6))) {
            probabilityStatistic.reset();
        } else {
            probabilityStatistic.recover();
        }
        
        decision.clear();
        
        if (TEXT_OUTPUT) System.out.println(probabilityStatistic.getAverage());
    }
    
    Node currentNode = new Node(0);
    
    if (probabilityStatistic.compare("path")) {
        currentNode.addNode(attributeNodes.get(Attribute.PATH_COST));
    }
    
    if (probabilityStatistic.compare("space")) {
        currentNode.addNode(attributeNodes.get(Attribute.STATION_SPACE));
    }
    
    if (probabilityStatistic.compare("distribution")) {

        if (stationFrequency) {
            currentNode.addNode(attributeNodes.get(Attribute.STATION_FREQUENCY));
        }
        if (agentFrequency) {
            currentNode.addNode(attributeNodes.get(Attribute.AGENT_FREQUENCY));
            
        }
    }
    
    if (probabilityStatistic.compare("directedTime")) {
        currentNode.addNode(attributeNodes.get(Attribute.INCOMING_TIME_CONNECTION));
        currentNode.addNode(attributeNodes.get(Attribute.OUTGOING_TIME_CONNECTION));
    }
    
    if (probabilityStatistic.compare("undirectedTime")) {
        currentNode.addNode(attributeNodes.get(Attribute.UNDIRECTED_TIME_CONNECTION));
    }
    
    

    if ((!stationFrequency && !agentFrequency || !probabilityStatistic.compare("distribution")) 
            && !probabilityStatistic.compare("space") && !probabilityStatistic.compare("path") && !probabilityStatistic.compare("directedTime") && !probabilityStatistic.compare("undirectedTime")) {
        currentNode.addNode(attributeNodes.get(Attribute.MAX_DISTRIBUTION));
    }
    
    firstRun = false;
    
    if (!decision.containsKey(me)) {
        decision.put(me, probabilityStatistic.getCurrentComparison());
    }
    
    return currentNode.evaluate(me, others, station);
}

public static void reward(Agent me, HashMap<Agent, Object> others, List<Station> stations, long time, double value,TimeStatistics timeStatistic) {
    if (decision.containsKey(me)) {
        probabilityStatistic.triggerCompare(decision.get(me), value);
        decision.remove(me);
    }

    probabilityStatistic.normalize();

    if (lastValue != time) {
        lastValue = time;

        probabilityStatistic.newRandom();
    }
}