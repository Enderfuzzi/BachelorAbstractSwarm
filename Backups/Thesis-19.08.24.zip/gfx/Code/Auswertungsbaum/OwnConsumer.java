interface OwnConsumer {
	double compute(Agent me, HashMap<Agent, Object> others, Station station);
}