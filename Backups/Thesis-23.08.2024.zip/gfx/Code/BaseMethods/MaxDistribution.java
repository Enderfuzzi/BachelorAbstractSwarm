private static double maxDistribution(Agent me, HashMap<Agent, Object> others, Station station) {
    if (stationSpace(me, others, station) != Integer.MAX_VALUE) {
        return -1.0 * stationTargeted(me, others, station) + 1.0 * stationSpace(me, others, station);
    }
    return 2 / (stationTargeted(me,others,station) + 1);
}

private static int stationSpace(StationType station) {
    if (station.space == -1) return Integer.MAX_VALUE;
    return station.space;
}

private static int stationTargeted(Agent me, HashMap<Agent, Object> others, Station station) {
    int counter = 0;
    for (Object object : others.values()) {
        if (object == null) continue;
        Object[] communication = (Object[]) object;
        if (((Station) communication[0]) == station) {
            counter += 1;
        }
    }
    if (TEXT_OUTPUT) System.out.println("Station target: " + station.name + " Number: " + counter);
    return counter;
}