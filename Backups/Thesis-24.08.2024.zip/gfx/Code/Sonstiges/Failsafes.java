
if (!otherStationsReachable(me, station)) {
		return -100;
}

if (agentSize(me, others, station) > stationSpace(me, others, station)) {
	return -100;
}

private static boolean otherStationsReachable(Agent me, Station station) {
	if (pathCost(me.previousTarget.type, station.type, edge -> (false)) == -1) return false;
	for (Map.Entry<Station, Integer> entry : me.necessities.entrySet()) {
		if (entry.getValue() <= 0) continue;
		if (pathCost(station.type, entry.getKey().type, edge -> (edge.incoming)) == -1) return false;
	}
	
	return true;
}