	/**
	 * Extracts the initial space of a station type. Returns 1 if the station type has no space attribute.
	 * @param station The station type to check.
	 * @return The space of a station or 1 if the station has no space attribute
	 */
	private static int stationSpace(StationType station) {
		if (station.space == -1) return 1;
		return station.space;
	}
	
	/**
	 * Similar to {@link Calculations#stationSpace(StationType)} with unused parameters for {@link OwnConsumer}
	 * @param me unused parameter
	 * @param others unused parameter
	 * @param The station to check
	 * @return The space of a station or 1 if the station has no space attribute
	 */
	private static int stationSpace(Agent me, HashMap<Agent, Object> others, Station station) {
		return stationSpace(station.type);
	}