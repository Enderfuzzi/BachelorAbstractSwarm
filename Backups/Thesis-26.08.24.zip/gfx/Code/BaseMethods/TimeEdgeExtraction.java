private static Predicate<TimeEdge> undirectedPredicate = edge -> (edge.incoming || edge.outgoing);
private static Predicate<TimeEdge> outgoingDirectedPredicate = edge -> (!edge.outgoing || edge.incoming);
private static Predicate<TimeEdge> incomingDirectedPredicate = edge -> (edge.outgoing || !edge.incoming);

private static double computeTimeConnectedStations(Agent me, HashMap<Agent, Object> others, List<ResultPair> connectedStations) {
    double result = 0.0;
    for (ResultPair pair : connectedStations) {
        result += timeAtStation(me, others, pair.station);
        result += pair.cost;
        result += stationTargeted(me, others, pair.station);
    }
    return result;
}

private static double computeTimeConnectedAgents(Agent me, HashMap<Agent, Object> others, Station station, List<Agent> connectedAgents) {
    double result = 0.0;
    for (Agent agent : connectedAgents) {
        result += estimatedWorkTimeLeft(agent, others, station);
    }
    return result;
}

private static int estimatedWorkTimeLeft(Agent me, HashMap<Agent, Object> others, Station station) {
    int result = 0;		
    for (Map.Entry<Station, Integer> entry : me.necessities.entrySet()) {
        if (entry.getValue() == 0) continue;
        result += timeAtStation(me, others ,entry.getKey());
    }
    
    if (me.frequency > 0) {
        int lowestTimeAtStation = Integer.MAX_VALUE;
        for (VisitEdge edge : me.type.visitEdges) {
            if (edge.connectedType instanceof StationType stationType) {
                lowestTimeAtStation = Math.max(lowestTimeAtStation, timeAtStation(me, stationType));
            }
        }
        
        result += lowestTimeAtStation * me.frequency;
    }
    
    return result;
}