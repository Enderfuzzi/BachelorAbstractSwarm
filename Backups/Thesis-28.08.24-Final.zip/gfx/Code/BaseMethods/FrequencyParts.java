if (me.frequency == -1) return 0.0;
double result = 0.0;
if (agentSize(me, others, station) * me.type.components.size() <= stationSpace(me, others, station)) {
    result += 1.0;
}

List<StationType> used = new ArrayList<>();
for (VisitEdge edge : me.type.visitEdges) {
    StationType stationType = (StationType) edge.connectedType;
    if (stationType == station.type) continue;
    if (used.contains(stationType)) continue;
    used.add(stationType);
    if (agentSize(me, others, station) * me.type.components.size() <= stationSpace(stationType)) {
        result -= 0.5;
    }
}

List<AgentType> usedAgent = new ArrayList<>();
usedAgent.add(me.type);
for (Agent agent : others.keySet()) {
    if (usedAgent.contains(agent.type)) continue;
    usedAgent.add(agent.type);
    
    boolean check = false;
    for (VisitEdge edge: agent.type.visitEdges) {
        StationType stationType = (StationType) edge.connectedType;
        if (stationType == station.type) {
            check = true;
            break;
        }
    }
    if (!check) continue;
    
    if (agentSize(agent, others, station) * agent.type.components.size() > stationSpace(me, others, station)) {
        result += 0.5;
    }
}


if (station.space >= agentSize(me, others, station)) {
    result += 0.5;
}