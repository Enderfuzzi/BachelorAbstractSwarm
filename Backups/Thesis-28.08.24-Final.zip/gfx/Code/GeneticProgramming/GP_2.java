if (!deactivateMutation) {
    evaluation = bestTrees.get(currentTreeIndex).copy();

    if (timeStatistic.newRun) {
        mutationProbability.newRandom();
        basicMutationProbability.newRandom();
    }
    
    if (timeStatistic.lastValue != timeStatistic.time || currentTrees.size() < 1) {
        if (mutationProbability.compare("mutation")) {
            
            if (basicMutationProbability.compare("value")) {
                evaluation = TreeMutation.valueMutation(evaluation);
            } else {
                evaluation = TreeMutation.mutateOperator(mutationStatistic, evaluation);
            }                          
        }
        
        if (!mutationProbability.compare("mutation") && mutationProbability.compare("crossover") && !treeFitness.isEmpty()) {
            
            List<Tree> crossover = treeFitness.get(random.nextInt(treeFitness.size())).trees;
            
            if (crossover.size() > currentTreeIndex) {
                evaluation = TreeMutation.crossover(evaluation, crossover.get(currentTreeIndex));
            } else {
                evaluation = TreeMutation.crossover(evaluation, crossover.get(crossover.size() - 1));
            }
        }
        
        
        
    } else {
        evaluation = currentTrees.get(currentTrees.size() - 1);
    }
} else {
    if (crossoverTree.size() > currentTreeIndex) {
        evaluation = crossoverTree.get(currentTreeIndex).copy();
    }
}


if (timeStatistic.newRun && !generateTree) {
    mutationProbability.newRandom();
    if (mutationProbability.compare("largeCrossover") && !treeFitness.isEmpty()) {
        deactivateMutation = true;
        
        crossoverTree = TreeMutation.largeCrossover(currentTrees, treeFitness.get(random.nextInt(treeFitness.size())).trees);
        
    } else {
        deactivateMutation = false;
    }
}

if (currentTrees.size() > 0) {
    evaluation = currentTrees.get(currentTrees.size() - 1);
}