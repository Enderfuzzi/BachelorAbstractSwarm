record Pair(StationType station, Integer cost) implements Comparable<Pair> {
    @Override
    public int compareTo(Pair other) {
        return Integer.compare(this.cost, other.cost);
    }	
};

private static int pathCost(StationType start, StationType target, Predicate<PlaceEdge> predicate) {
    PriorityQueue<Pair> queue = new PriorityQueue<>();
    List<StationType> used = new ArrayList<>();
    queue.add(new Pair(start, 0));
    while (!queue.isEmpty()) {
        Pair current = queue.poll();
        if (used.contains(current.station())) continue;
        used.add(current.station());
        if (current.station() == target) {
            if (TEXT_OUTPUT) System.out.println(String.format("Path calculation: %s to %s with cost: %d", start.name, target.name, current.cost()));
            return current.cost();
        }
        
        for (PlaceEdge edge : current.station().placeEdges) {
            if (predicate.test(edge)) continue;
            queue.add(new Pair((StationType) edge.connectedType, current.cost() + edge.weight));
        }	
    }
    return -1;
}