if (timeStatistic.newRun) {
    probabilityStatistic.newRandom();
    if (timeStatistic.newBestRun || (timeStatistic.lastRunCompleted && timeStatistic.currentTwT <= Math.round(timeStatistic.lowestTwT * 1.6))) {
        probabilityStatistic.reset();
    } else {
        probabilityStatistic.recover();
    }
    
    decision.clear();
}