private class Pair {
    private double randomValue;
    private double threshold;
    
    private void checkThreshold() {
        this.threshold = Math.max(this.threshold, 0.05);
    }
    
    public void newRandom() {
        this.randomValue = random.nextDouble();
    }
    
    public boolean compare() {
        return randomValue <= threshold;
    }
}