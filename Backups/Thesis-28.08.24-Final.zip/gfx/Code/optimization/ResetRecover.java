public void reset() {
    addToPast();
    Pair highest = null;
    for (Pair pair : map.values()) {
        if (highest == null || highest.getThreshold() < pair.getThreshold()) {
            highest = pair;
        }
    }
    for (Map.Entry<String, Pair> entry : map.entrySet()) {
        if (entry.getValue() != highest) {
            entry.getValue().setThreshold(computeAverage(entry.getKey()));
        } else {
            entry.getValue().setThreshold(0);
        }
    }
}

public void recover() {
    for (Map.Entry<String, List<Double>> entry : pastValues.entrySet()) {
        if (map.containsKey(entry.getKey())) {
            if (entry.getValue().size() > 0) {
                map.get(entry.getKey()).setThreshold(entry.getValue().get(entry.getValue().size() - 1));
            } else {
                map.get(entry.getKey()).setThreshold(0.35);
            }
        }
    }
}